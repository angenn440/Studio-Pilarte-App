//
//  Pilarte_AppApp.swift
//  Pilarte App
//
//  Created by Alumno on 25/04/25.
//

import SwiftUI

@main
struct Pilarte_AppApp: App {
    @StateObject var authManager = AuthManager()
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                if authManager.isLoggedIn {
                    ContentView()
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing),
                            removal: .move(edge: .leading)
                        ))
                } else {
                    LoginView()
                        .transition(.asymmetric(
                            insertion: .move(edge: .leading),
                            removal: .move(edge: .trailing)
                        ))
                }
            }
            .animation(.default, value: authManager.isLoggedIn)
            .environmentObject(authManager)
        }
    }
}
