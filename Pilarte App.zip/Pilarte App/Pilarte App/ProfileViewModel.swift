//
//  File.swift
//  Pilarte App
//
//  Created by Alumno on 25/04/25.
//
import Foundation
import SwiftUI

class ProfileViewModel: ObservableObject {
    @Published var profileImage: UIImage? = nil
}
