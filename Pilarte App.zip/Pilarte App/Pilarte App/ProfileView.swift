//
//  ProfileView.swift
//  Pilarte App
//
//  Created by Alexis Rodriguez  on 28/04/25.
//


import SwiftUI
import SwiftUI

struct ProfileView: View {
    @ObservedObject var profileViewModel: ProfileViewModel

    var body: some View {
        Text("Vista de perfil")
    }
}
