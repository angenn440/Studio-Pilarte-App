//
//  TextSettings.swift
//  Pilarte App
//
//  Created by Alumno on 25/04/25.
//
import Foundation

let countryList3 = [
    "Usuario"
    
]
let countryList = [
    "Notificaciones",
    "Idioma"
    
]

let countryList1 = [
    "Datos de la cuenta",
    "Contraseña"
    
]
let countryList2 = [
    "Cambiar cuenta",
    
]
