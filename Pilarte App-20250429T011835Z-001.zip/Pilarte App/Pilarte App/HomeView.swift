//
//  HomeView.swift
//  Pilarte App
//
//  Created by Alumno on 25/04/25.
//

import SwiftUI

struct HomeView: View {
    @StateObject public var profileViewModel = ProfileViewModel()
    
    // Datos de ejemplo
    let proximasSesiones = [
        SesionPilates(id: 1, tipo: "Pilates Reformer", instructor: "Ana Martínez", fecha: "15 Mayo 2024", hora: "10:00 AM", duracion: "60 min", nivel: "Intermedio"),
        SesionPilates(id: 2, tipo: "Pilates Mat", instructor: "Carlos López", fecha: "20 Mayo 2024", hora: "4:30 PM", duracion: "45 min", nivel: "Principiante")
    ]
    
    let tipsPilates = [
        TipPilates(id: 1, titulo: "Respiración", contenido: "Coordina tu respiración con los movimientos. Inhala al preparar y exhala al ejecutar.", icono: "wind"),
        TipPilates(id: 2, titulo: "Ropa adecuada", contenido: "Usa ropa cómoda que te permita moverte libremente pero no demasiado holgada.", icono: "tshirt")
    ]
    
    let proximasFacturas = [
        Factura(id: 1, concepto: "Mensualidad Mayo", monto: "$1,200.00", vencimiento: "05 Jun 2024", estado: "Pendiente"),
        Factura(id: 2, concepto: "Clase particular", monto: "$450.00", vencimiento: "12 Jun 2024", estado: "Por vencer")
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("White").ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Encabezado
                        HStack {
                            Text("Bienvenido")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.black)
                            
                            Spacer()
                            

                        }
                        .padding()
                        
                        // Sección de próximas sesiones
                        seccionProximasSesiones()
                        
                        // Sección de tips
                        seccionTips()
                        
                        // Sección de facturas
                        seccionFacturas()
                        
                        Spacer()
                    }
                    .padding(.bottom, 20)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    // MARK: - Componentes
    
    private var profileImage: some View {
        Group {
            if let image = profileViewModel.profileImage {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: 75, height: 75)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color("POPUP"), lineWidth: 2))
                    .shadow(radius: 5)
            } else {
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 75, height: 75)
                    .foregroundColor(.text)
            }
        }
    }
    
    private func seccionProximasSesiones() -> some View {
        VStack(alignment: .leading) {
            Text("Tus próximas sesiones")
                .font(.headline)
                .padding(.horizontal)
                .padding(.top, 10)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(proximasSesiones) { sesion in
                        SesionCard(sesion: sesion)
                    }
                }
                .padding()
            }
        }
        .background(Color("WidgetBackground")) // #FFFBE7
        .cornerRadius(15)
        .shadow(radius: 3)
        .padding(.horizontal)
    }
    
    private func seccionTips() -> some View {
        VStack(alignment: .leading) {
            Text("Tips para tus clases")
                .font(.headline)
                .padding(.horizontal)
                .padding(.top, 10)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(tipsPilates) { tip in
                        TipCard(tip: tip)
                    }
                }
                .padding()
            }
        }
        .background(Color("WidgetBackground")) // #FFFBE7
        .cornerRadius(15)
        .shadow(radius: 3)
        .padding(.horizontal)
    }
    
    private func seccionFacturas() -> some View {
        VStack(alignment: .leading) {
            Text("Tus próximas facturas")
                .font(.headline)
                .padding(.horizontal)
                .padding(.top, 10)
            
            VStack(spacing: 12) {
                ForEach(proximasFacturas) { factura in
                    FacturaCard(factura: factura)
                }
            }
            .padding()
        }
        .background(Color("WidgetBackground")) // #FFFBE7
        .cornerRadius(15)
        .shadow(radius: 3)
        .padding(.horizontal)
    }
}

// MARK: - Modelos de Datos

struct SesionPilates: Identifiable {
    let id: Int
    let tipo: String
    let instructor: String
    let fecha: String
    let hora: String
    let duracion: String
    let nivel: String
}

struct TipPilates: Identifiable {
    let id: Int
    let titulo: String
    let contenido: String
    let icono: String
}

struct Factura: Identifiable {
    let id: Int
    let concepto: String
    let monto: String
    let vencimiento: String
    let estado: String
}

// MARK: - Componentes de Tarjetas

struct SesionCard: View {
    let sesion: SesionPilates
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "figure.pilates")
                    .foregroundColor(.greenDark)
                Text(sesion.tipo)
                    .font(.subheadline)
                    .fontWeight(.bold)
                Spacer()
                Text(sesion.nivel)
                    .font(.caption)
                    .padding(5)
                    .background(nivelColor)
                    .cornerRadius(5)
            }
            
            Divider()
            
            HStack {
                Image(systemName: "person.fill")
                Text("Instructor: \(sesion.instructor)")
                    .font(.caption)
            }
            
            HStack {
                Image(systemName: "calendar")
                Text(sesion.fecha)
                    .font(.caption)
                
                Image(systemName: "clock")
                    .padding(.leading, 5)
                Text("\(sesion.hora) (\(sesion.duracion))")
                    .font(.caption)
            }
        }
        .padding()
        .frame(width: 250)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.green.opacity(0.3), lineWidth: 1)
        )
        .shadow(color: Color.green.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    private var nivelColor: Color {
        switch sesion.nivel {
        case "Principiante": return Color.green.opacity(0.2)
        case "Intermedio": return Color.greenDark.opacity(0.2)
        case "Avanzado": return Color.red.opacity(0.2)
        default: return Color.gray.opacity(0.2)
        }
    }
}

struct TipCard: View {
    let tip: TipPilates
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: tip.icono)
                    .foregroundColor(.orange)
                Text(tip.titulo)
                    .font(.subheadline)
                    .fontWeight(.bold)
            }
            
            Divider()
            
            Text(tip.contenido)
                .font(.caption)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding()
        .frame(width: 180, height: 150)
        .background(Color.white)
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.orange.opacity(0.3), lineWidth: 1)
        )
        .shadow(color: Color.orange.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct FacturaCard: View {
    let factura: Factura
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(factura.concepto)
                    .font(.subheadline)
                    .fontWeight(.medium)
                
                Text("Vence: \(factura.vencimiento)")
                    .font(.caption2)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            VStack(alignment: .trailing, spacing: 4) {
                Text(factura.monto)
                    .font(.subheadline)
                    .fontWeight(.bold)
                
                Text(factura.estado)
                    .font(.caption2)
                    .foregroundColor(estadoColor)
                    .padding(4)
                    .background(estadoColor.opacity(0.2))
                    .cornerRadius(4)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray.opacity(0.2), lineWidth: 1)
        )
    }
    
    private var estadoColor: Color {
        switch factura.estado {
        case "Pendiente": return .red
        case "Por vencer": return .orange
        default: return .gray
        }
    }
}

// MARK: - Previews

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
