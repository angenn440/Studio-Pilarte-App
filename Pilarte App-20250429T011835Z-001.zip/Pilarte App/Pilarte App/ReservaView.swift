//
//  ReservaView.swift
//  Pilarte App
//
//  Created by Alumno on 25/04/25.
//

import SwiftUI
import EventKit

struct ReservaView: View {
    @State private var selectedDate = Date()
    @State private var selectedTime: String?
    @State private var selectedClassType = "Pilates Mat"
    @State private var showingConfirmation = false
    @State private var showingCalendarAlert = false
    @State private var calendarAccessGranted = false
    
    // Datos configurables
    let availableTimes = ["7:00 AM", "8:00 AM", "9:00 AM", "10:00 AM", "4:00 PM", "5:00 PM", "6:00 PM", "7:00 PM"]
    let classTypes = ["Pilates Mat", "Pilates Reformer", "Pilates Aéreo", "Clase Privada"]
    let instructors = ["Ana Martínez", "Carlos López", "María Fernández"]
    @State private var selectedInstructor = "Ana Martínez"
    
    // Store para eventos del calendario
    let eventStore = EKEventStore()
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                headerSection()
                classTypePicker()
                weekCalendarView()
                availableTimesHorizontalScroll()
                instructorPicker()
                confirmButton()
            }
            .padding(.vertical)
        }
        .background(Color("White").ignoresSafeArea())
        .navigationTitle("Reservar Clase")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Reserva Confirmada", isPresented: $showingConfirmation) {
            Button("Añadir al Calendario") {
                addEventToCalendar()
            }
            Button("OK", role: .cancel) {}
        } message: {
            Text("Tu clase de \(selectedClassType) con \(selectedInstructor) el \(selectedDate.formatted(date: .abbreviated, time: .omitted)) a las \(selectedTime ?? "") ha sido reservada.")
        }
        .alert("Acceso al Calendario", isPresented: $showingCalendarAlert) {
            Button("Ajustes", role: .none) {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            Button("Cancelar", role: .cancel) {}
        } message: {
            Text("Por favor permite acceso al calendario en Ajustes para añadir tu reserva automáticamente.")
        }
        .onAppear {
            requestCalendarAccess()
        }
    }
    
    // MARK: - Funciones del Calendario
    
    private func requestCalendarAccess() {
        eventStore.requestAccess(to: .event) { granted, error in
            DispatchQueue.main.async {
                self.calendarAccessGranted = granted
                if let error = error {
                    print("Error al solicitar acceso al calendario: \(error.localizedDescription)")
                }
            }
        }
    }
    
    private func addEventToCalendar() {
        guard calendarAccessGranted else {
            showingCalendarAlert = true
            return
        }
        
        guard let selectedTime = selectedTime else { return }
        
        // Convertir fecha y hora seleccionadas a Date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        dateFormatter.locale = Locale(identifier: "es_MX")
        
        guard let timeDate = dateFormatter.date(from: selectedTime) else { return }
        
        // Combinar fecha y hora
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: selectedDate)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: timeDate)
        
        guard let eventDate = calendar.date(byAdding: timeComponents, to: calendar.date(from: dateComponents)!) else { return }
        
        // Crear el evento
        let event = EKEvent(eventStore: eventStore)
        event.title = "Clase de \(selectedClassType) con \(selectedInstructor)"
        event.startDate = eventDate
        event.endDate = calendar.date(byAdding: .hour, value: 1, to: eventDate) // Duración de 1 hora
        event.notes = "Reserva realizada a través de Pilarte App"
        event.calendar = eventStore.defaultCalendarForNewEvents
        
        // Añadir alarma 1 hora antes
        let alarm = EKAlarm(relativeOffset: -3600) // 1 hora antes
        event.addAlarm(alarm)
        
        do {
            try eventStore.save(event, span: .thisEvent)
            print("Evento añadido al calendario")
        } catch {
            print("Error al guardar evento: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Componentes (igual que antes)
    private func headerSection() -> some View {
        Text("Reserva tu sesión")
            .font(.title2)
            .fontWeight(.bold)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal)
    }
    
    private func classTypePicker() -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Tipo de clase")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            Picker("", selection: $selectedClassType) {
                ForEach(classTypes, id: \.self) { type in
                    Text(type).tag(type)
                }
            }
            .pickerStyle(.menu)
            .padding()
            .background(Color("WidgetBackground"))
            .cornerRadius(10)
        }
        .padding(.horizontal)
    }
    
    private func weekCalendarView() -> some View {
        VStack(spacing: 10) {
            // Encabezado con mes/año
            Text(selectedDate.monthYearFormatted())
                .font(.headline)
                .padding(.bottom, 5)
            
            // Días de la semana
            HStack(spacing: 0) {
                ForEach(0..<7, id: \.self) { dayOffset in
                    let date = Calendar.current.date(byAdding: .day, value: dayOffset, to: selectedDate.startOfWeek())!
                    dayView(for: date)
                }
            }
        }
        .padding()
        .background(Color("WidgetBackground"))
        .cornerRadius(15)
        .padding(.horizontal)
    }
    
    private func dayView(for date: Date) -> some View {
        let isSelected = Calendar.current.isDate(date, inSameDayAs: selectedDate)
        
        return Button(action: { selectedDate = date }) {
            VStack(spacing: 6) {
                Text(date.dayOfWeekLetter())
                    .font(.caption)
                    .foregroundColor(isSelected ? .white : .gray)
                
                Text(date.dayNumber())
                    .font(isSelected ? .headline : .subheadline)
                    .foregroundColor(isSelected ? .white : .primary)
                
                if isSelected {
                    Circle()
                        .fill(Color.white)
                        .frame(width: 6, height: 6)
                } else {
                    Spacer()
                        .frame(height: 6)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(isSelected ? Color("Green") : Color.clear)
            .cornerRadius(8)
        }
    }
    
    private func availableTimesHorizontalScroll() -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Horarios disponibles")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(availableTimes, id: \.self) { time in
                        timeSlotButton(time: time)
                    }
                }
                .padding(.horizontal)
            }
        }
    }
    
    private func timeSlotButton(time: String) -> some View {
        Button(action: { selectedTime = time }) {
            Text(time)
                .font(.subheadline)
                .padding(12)
                .frame(width: 100)
                .background(selectedTime == time ? Color("Green") : Color("WidgetBackground"))
                .foregroundColor(selectedTime == time ? .white : .primary)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                )
        }
    }
    
    private func instructorPicker() -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Instructor")
                .font(.subheadline)
                .foregroundColor(.gray)
            
            Picker("", selection: $selectedInstructor) {
                ForEach(instructors, id: \.self) { instructor in
                    Text(instructor).tag(instructor)
                }
            }
            .pickerStyle(.menu)
            .padding()
            .background(Color("WidgetBackground"))
            .cornerRadius(10)
        }
        .padding(.horizontal)
    }
    
    private func confirmButton() -> some View {
        Button(action: {
            guard selectedTime != nil else { return }
            showingConfirmation = true
        }) {
            HStack {
                Spacer()
                Text("Confirmar Reserva")
                    .fontWeight(.semibold)
                Spacer()
            }
            .padding()
            .background(selectedTime != nil ? Color("Green") : Color.gray)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding(.horizontal)
        .disabled(selectedTime == nil)
        .opacity(selectedTime == nil ? 0.7 : 1.0)
    }
}

// MARK: - Extensiones para Date (igual que antes)
extension Date {
    func startOfWeek() -> Date {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)
        return calendar.date(from: components)!
    }
    
    func monthYearFormatted() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: self)
    }
    
    func dayOfWeekLetter() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "E"
        return formatter.string(from: self).prefix(1).uppercased()
    }
    
    func dayNumber() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "d"
        return formatter.string(from: self)
    }
}

// MARK: - Preview
struct ReservaView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            ReservaView()
        }
    }
}
