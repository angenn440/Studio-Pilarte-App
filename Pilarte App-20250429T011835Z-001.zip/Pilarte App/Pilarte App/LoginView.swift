
//  LoginView.swift
//  Pilarte App
//
//  Created by Alumno on 25/04/25.
//

import SwiftUI

// Manager para manejar los datos de usuario
class UserManager {
    static let shared = UserManager()
    private let defaults = UserDefaults.standard
    private let usersKey = "pilarteAppUsers"
    
    // Registrar nuevo usuario
    func registerUser(name: String, email: String, password: String) -> Bool {
        var users = getAllUsers()
        
        if users.contains(where: { $0["email"]?.lowercased() == email.lowercased() }) {
            return false
        }
        
        let newUser = [
            "name": name,
            "email": email.lowercased(),
            "password": password // En producción, deberías hashear la contraseña
        ]
        
        users.append(newUser)
        defaults.set(users, forKey: usersKey)
        return true
    }
    
    // Iniciar sesión
    func loginUser(email: String, password: String) -> Bool {
        let users = getAllUsers()
        return users.contains {
            $0["email"]?.lowercased() == email.lowercased() &&
            $0["password"] == password
        }
    }
    
    // Obtener todos los usuarios
    private func getAllUsers() -> [[String: String]] {
        return defaults.array(forKey: usersKey) as? [[String: String]] ?? []
    }
}


    struct LoginView: View {
    @EnvironmentObject var authManager: AuthManager
    @State private var isLoginMode = true
    @State private var email = ""
    @State private var password = ""
    @State private var name = ""
    @State private var isLoggedIn = false
    @State private var showAlert = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
        var body: some View {
            NavigationStack {
                ZStack {
                // Fondo claro
                Color(.systemBackground)
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Encabezado exacto como en la imagen
                    VStack(spacing: 4) {
                        Text("El arte")
                            .font(.system(size: 28, weight: .light))
                            .foregroundColor(.primary)
                        
                        Text("De")
                            .font(.system(size: 36, weight: .bold))
                            .foregroundColor(Color("Green"))
                        
                        Text("Reformar")
                            .font(.system(size: 28, weight: .light))
                            .foregroundColor(.primary)
                        
                        Text("Tu cuerpo")
                            .font(.system(size: 36, weight: .bold))
                            .foregroundColor(Color("Green"))
                    }
                    .padding(.top, 60)
                    .padding(.bottom, 40)
                    
                    // Card de autenticación
                    VStack(spacing: 20) {
                        if isLoginMode {
                            Text("Bienvenido")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .padding(.bottom, 10)
                        } else {
                            TextField("Nombre completo", text: $name)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .padding(.horizontal)
                        }
                        
                        TextField("Email", text: $email)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                            .padding(.horizontal)
                        
                        SecureField("Contraseña", text: $password)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding(.horizontal)
                        
                        Button(action: handleAuthAction) {
                            Text(isLoginMode ? "Iniciar sesión" : "Registrarse")
                                .fontWeight(.semibold)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color("Green"))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .padding(.horizontal)
                        }
                        
                        Button(action: {
                            withAnimation {
                                isLoginMode.toggle()
                            }
                        }) {
                            Text(isLoginMode ? "¿Aún no tienes una cuenta?" : "Ya tienes una cuenta")
                                .foregroundColor(Color("Green"))
                                .font(.subheadline)
                        }
                    }
                    .padding(.vertical)
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(15)
                    .shadow(radius: 5)
                    .padding(.horizontal, 30)
                    
                    Spacer()
                }
            }
            .alert(alertTitle, isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
            .navigationDestination(isPresented: $isLoggedIn) {
                ContentView()
            }
            .navigationBarHidden(true)
        }
    }
    
    private func handleAuthAction() {
        
        if isLoginMode {
            handleLogin()
        } else {
            handleRegistration()
        }
    }
    
    private func handleLogin() {
        guard !email.isEmpty, !password.isEmpty else {
            showAlert(title: "Error", message: "Por favor completa todos los campos")
            return
        }
        
        if UserManager.shared.loginUser(email: email, password: password) {
            isLoggedIn = true
        } else {
            showAlert(title: "Error", message: "Email o contraseña incorrectos")
        }
    }
    
    private func handleRegistration() {
        guard !name.isEmpty, !email.isEmpty, !password.isEmpty else {
            showAlert(title: "Error", message: "Por favor completa todos los campos")
            return
        }
        
        guard email.contains("@") && email.contains(".") else {
            showAlert(title: "Error", message: "Por favor ingresa un email válido")
            return
        }
        
        guard password.count >= 6 else {
            showAlert(title: "Error", message: "La contraseña debe tener al menos 6 caracteres")
            return
        }
        
        if UserManager.shared.registerUser(name: name, email: email, password: password) {
            showAlert(
                title: "Registro exitoso",
                message: "Tu cuenta ha sido creada. Ahora puedes iniciar sesión."
            )
            // Limpiar campos y cambiar a modo login
            name = ""
            email = ""
            password = ""
            isLoginMode = true
        } else {
            showAlert(title: "Error", message: "Este email ya está registrado")
        }
    }
    
    private func showAlert(title: String, message: String) {
        alertTitle = title
        alertMessage = message
        showAlert = true
    }
}

// Extensión para manejar cierre de sesión
extension EnvironmentValues {
    var dismissAction: () -> Void {
        get { self[DismissActionKey.self] }
        set { self[DismissActionKey.self] = newValue }
    }
}

struct DismissActionKey: EnvironmentKey {
    static let defaultValue: () -> Void = {}
}

// Vista previa
struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
